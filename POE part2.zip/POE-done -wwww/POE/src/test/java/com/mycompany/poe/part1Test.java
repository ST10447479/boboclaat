/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit5TestClass.java to edit this template
 */
package com.mycompany.poe;

import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

/**
 *
 * @author RC_Student_lab
 */
public class part1Test {
    
    public part1Test() {
    }
    
    @BeforeAll
    public static void setUpClass() {
    }
    
    @AfterAll
    public static void tearDownClass() {
    }

    /**
     * Test of registerUser method, of class part1.
     */
    @Test
    public void testRegisterUser() {
    }

    /**
     * Test of checkUserName method, of class part1.
     */
    @Test
    public void testCheckUserName() {
    }

    /**
     * Test of PasswordMaker method, of class part1.
     */
    @Test
    public void testPasswordMaker() {
    }

    /**
     * Test of checkPasswordComplexity method, of class part1.
     */
    @Test
    public void testCheckPasswordComplexity() {
    }

    /**
     * Test of returnLoginStatus method, of class part1.
     */
    @Test
    public void testReturnLoginStatus() {
    }

    /**
     * Test of LoginUser method, of class part1.
     */
    @Test
    public void testLoginUser() {
    }
    
}
