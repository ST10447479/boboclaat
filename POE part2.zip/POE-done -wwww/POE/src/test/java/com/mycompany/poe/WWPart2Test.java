/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit5TestClass.java to edit this template
 */
package com.mycompany.poe;

import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

/**
 *
 * @author RC_Student_lab
 */
public class WWPart2Test {
    
    public WWPart2Test() {
    }
    
    @BeforeAll
    public static void setUpClass() {
    }
    
    @AfterAll
    public static void tearDownClass() {
    }

    /**
     * Test of main method, of class WWPart2.
     */
    @Test
    public void testMain() {
    }

    /**
     * Test of select method, of class WWPart2.
     */
    @Test
    public void testSelect() {
    }

    /**
     * Test of addTask method, of class WWPart2.
     */
    @Test
    public void testAddTask() {
    }

    /**
     * Test of pick method, of class WWPart2.
     */
    @Test
    public void testPick() {
    }

    /**
     * Test of checkTaskDescription method, of class WWPart2.
     */
    @Test
    public void testCheckTaskDescription() {
    }

    /**
     * Test of returnTotalHours method, of class WWPart2.
     */
    @Test
    public void testReturnTotalHours() {
    }

    /**
     * Test of printTaskDetails method, of class WWPart2.
     */
    @Test
    public void testPrintTaskDetails() {
    }

    /**
     * Test of createTaskID method, of class WWPart2.
     */
    @Test
    public void testCreateTaskID() {
    }
    
}
