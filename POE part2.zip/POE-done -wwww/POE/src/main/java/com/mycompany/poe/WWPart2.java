/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.poe;

import java.util.ArrayList;
import javax.swing.JOptionPane;

/**
 *
 * @author RC_Student_lab
 */
public class WWPart2 {
    
    public static void main(String[] args) 
    {
               
    }
    
    public void select()
    {      
        
        String options = "1) add tasks 2) show report 3) Quit";
        int selector = Integer.parseInt(JOptionPane.showInputDialog(null,"please enter a number " + options));
             
      //if statements that will allow user to choose what to do
      
      //add tasks
      if(selector == 1)
      {
        JOptionPane.showMessageDialog(null, "Add tasks");
        addTask();
      }
      
      //still in development
      if(selector == 2)
      {
        JOptionPane.showMessageDialog(null ,"Coming Soon");
        select();
      }
      
      //Quit
      if(selector == 3)
      {        
        System.exit(0);
      }
    
    }
    
    
    
    //Add tasks start here
    
    public int limit;
    
    public void addTask() 
    {
        ArrayList<String> tasks = new ArrayList<>();
        ArrayList<Integer> time = new ArrayList<>(); // Change to Integer to store hours
        ArrayList<String> taskDescription = new ArrayList<>();
        ArrayList<String> developerDetails = new ArrayList<>();
        ArrayList<String> taskIDs = new ArrayList<>();
        ArrayList<String> taskStatus = new ArrayList<>();

        limit = Integer.parseInt(JOptionPane.showInputDialog("Please enter the number of tasks to do"));
        
        //limit controls loop and therefore number of tasks 
        for (int i = 0; i < limit; i++) {
            String task = JOptionPane.showInputDialog("Please enter task " + (i + 1) + ":");
            tasks.add(task);

            String name = JOptionPane.showInputDialog("Please enter the name associated with task " + (i + 1) + ":");
            developerDetails.add(name);
            
            //Loop will continue until boolean condition which is 50 characters is met
            String details;
            while (true) 
            {
                details = JOptionPane.showInputDialog("Please enter task description for task " + (i + 1) + ":");
                if (checkTaskDescription(details)) 
                {
                    break;
                } 
                else 
                {
                    JOptionPane.showMessageDialog(null, "Task description must be 50 characters or less. Please re-enter.");
                }
            }
            
            //boolean for loop
            taskDescription.add(details);

            //time for each task
            int hours = Integer.parseInt(JOptionPane.showInputDialog(null, "How long is this task going to take (in hours)?"));
            time.add(hours);

            //Loop will continue until boolean condition which is picking the correct input
            String status;
            while (true) 
            {
                status = JOptionPane.showInputDialog("Enter the status for task " + (i + 1) + " (done, doing, to do):");
                if (status.equalsIgnoreCase("done") || status.equalsIgnoreCase("doing") || status.equalsIgnoreCase("to do")) 
                {
                    break;
                } 
                else 
                {
                    JOptionPane.showMessageDialog(null, "Invalid status. Please enter 'done', 'doing', or 'to do'.");
                }
            }
            
            //boolean for task status
            taskStatus.add(status);

            //fuction for task ID
            String taskID = createTaskID(task, i + 1, name);
            taskIDs.add(taskID);
        }

        //this function will allow you to quit or see the menu
        pick(tasks, taskDescription, developerDetails, time, taskIDs, taskStatus);
    }

    
    public void pick(ArrayList<String> tasks, ArrayList<String> taskDescription, ArrayList<String> developerDetails, ArrayList<Integer> time, ArrayList<String> taskIDs, ArrayList<String> taskStatus) 
    {
        int pickOption = Integer.parseInt(JOptionPane.showInputDialog(null, "Please enter a number:\n1) Show all tasks\n2) Quit"));

        if (pickOption == 1) 
        {
            //this function will show all the information about each task
            printTaskDetails(tasks, taskDescription, developerDetails, time, taskIDs, taskStatus);
            System.exit(0);
        } 
        if (pickOption == 2) 
        {
            System.exit(0);
        } 
        else 
        {
            //loop
            JOptionPane.showMessageDialog(null, "Invalid option. Please enter 1 or 2.");
            pick(tasks, taskDescription, developerDetails, time, taskIDs, taskStatus);
        }
    }

    
    public boolean checkTaskDescription(String description) {
        // Method to check if task description is 50 characters or less
        return description.length() <= 50;
    }

    public int returnTotalHours(ArrayList<Integer> time) {
        // Calculate total hours of all tasks
        int totalHours = 0;
        for (int hours : time) {
            totalHours += hours;
        }
        return totalHours;
    }

     //this function displays all tasks and details
    public void printTaskDetails(ArrayList<String> tasks, ArrayList<String> taskDescription, ArrayList<String> developerDetails, ArrayList<Integer> time, ArrayList<String> taskIDs, ArrayList<String> taskStatus) 
    {
       
        StringBuilder allTasks = new StringBuilder("All tasks and associated details:\n");

        //this part controls the format
        for (int i = 0; i < limit; i++) 
        {
            allTasks.append("Task ID: ").append(taskIDs.get(i)).append("\n")
                    .append("Task ").append(i + 1).append(": ").append(tasks.get(i))
                    .append(" (Assigned to: ").append(developerDetails.get(i)).append(")\n")
                    .append("Description: ").append(taskDescription.get(i)).append("\n")
                    .append("Time: ").append(time.get(i)).append(" hours\n")
                    .append("Status: ").append(taskStatus.get(i)).append("\n\n");
        }
        
        int totalHours = returnTotalHours(time);
        allTasks.append("Total hours for all tasks: ").append(totalHours).append(" hours\n");
        
        //displays info
        JOptionPane.showMessageDialog(null, allTasks.toString());
    }

    public String createTaskID(String task, int taskNumber, String name) 
    {
        //Generate a unique task ID
        String taskPart = task.length() >= 2 ? task.substring(0, 2).toUpperCase() : task.toUpperCase();
        String namePart = name.length() >= 3 ? name.substring(name.length() - 3).toUpperCase() : name.toUpperCase();
        return taskPart + ":" + taskNumber + ":" + namePart;
    }   
}
